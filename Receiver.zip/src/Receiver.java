import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.jms.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Enumeration;

/**
 * Created by Kamil on 29.04.2017.
 */

public class Receiver implements MessageListener{

    @Resource(mappedName = "java:/ConnectionFactory")
    private TopicConnectionFactory connectionFactory;

    //@Resource(mappedName = "jms/myQueue")
    //Queue myQueue;

    private String message2 = "";
    private String name ="R1";

    public String receiveMessage() {
        try {
            InitialContext context = new InitialContext();
            Topic queue = (Topic) context.lookup("java:/jms/topics/Topic");
            TopicConnection connection = connectionFactory.createTopicConnection();
            TopicSession session = connection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
            TopicSubscriber subscriber = session.createSubscriber(queue);
            connection.start();
            subscriber.setMessageListener(this);

            return "";
        } catch (JMSException e) {
            e.printStackTrace();
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return "";
    }

    public String getMessage2() {
        return message2;
    }

    public void setMessage2(String message2) {
        this.message2 = message2;
    }

    @Override
    public void onMessage(Message message) {
        TextMessage msg=(TextMessage)message;

        try {
            if(msg.getStringProperty("typ").equals(name)){
                System.out.println("Receiver:"+msg.getText());
                message2 = msg.getText();
            }
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}
